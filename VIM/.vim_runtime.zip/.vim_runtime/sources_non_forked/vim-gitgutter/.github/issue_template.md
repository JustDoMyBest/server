> What is the latest commit SHA in your installed vim-gitgutter?

> What vim/nvim version are you on?

> If no signs are showing at all, what does `:echo b:gitgutter.path` give?

> If no signs are showing at all, and the `path` value is a path and not `-2`, does it work with `let g:gitgutter_grep=''`?

